export interface User {
  id: string;
  email: string;
  username: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  role: 'ADMIN' | 'EDITOR' | 'AUTHOR';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  color?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Post {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  featuredImage?: string;
  status: 'DRAFT' | 'PUBLISHED' | 'SCHEDULED' | 'PRIVATE' | 'TRASH';
  publishedAt?: string;
  scheduledAt?: string;
  createdAt: string;
  updatedAt: string;
  
  // SEO fields
  metaTitle?: string;
  metaDescription?: string;
  canonicalUrl?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  
  // Analytics
  viewCount: number;
  likeCount: number;
  shareCount: number;
  
  // Relations
  author: User;
  category?: Category;
  tags: Tag[];
  comments?: Comment[];
  commentCount?: number;
}

export interface Comment {
  id: string;
  content: string;
  status: 'PENDING' | 'APPROVED' | 'SPAM' | 'TRASH';
  authorName?: string;
  authorEmail?: string;
  authorUrl?: string;
  createdAt: string;
  updatedAt: string;
  
  // Relations
  post: Post;
  user?: User;
  parent?: Comment;
  replies?: Comment[];
}

export interface Media {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  url: string;
  alt?: string;
  caption?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Analytics {
  totalViews: number;
  uniqueViews: number;
  period: number;
}

export interface PostAnalytics extends Analytics {
  post: {
    id: string;
    title: string;
    slug: string;
    publishedAt?: string;
  };
  allTimeViews: number;
  viewsByDay: Array<{
    date: string;
    views: number;
    uniqueViews: number;
  }>;
  topReferrers: Array<{
    referrer: string;
    views: number;
  }>;
}

export interface DashboardAnalytics {
  summary: Analytics;
  topPosts: Array<{
    id: string;
    title: string;
    slug: string;
    viewCount: number;
    publishedAt?: string;
  }>;
  viewsByDay: Array<{
    date: string;
    views: number;
    uniqueViews: number;
  }>;
  topReferrers: Array<{
    referrer: string;
    views: number;
  }>;
}

export interface SEOAnalysis {
  score: number;
  status: 'excellent' | 'good' | 'needs-improvement' | 'poor';
  issues: string[];
  suggestions: string[];
  checks: {
    [key: string]: {
      status: 'success' | 'warning' | 'error' | 'info';
      message: string;
    };
  };
  keywordDensity?: {
    [word: string]: {
      count: number;
      density: string;
    };
  };
}

export interface Backup {
  id: string;
  filename: string;
  size: number;
  type: 'FULL' | 'POSTS_ONLY' | 'MEDIA_ONLY';
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  createdAt: string;
  completedAt?: string;
  error?: string;
}

export interface BackupSchedule {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'monthly';
  time: string;
  includeMedia: boolean;
}

export interface ApiResponse<T> {
  data?: T;
  message?: string;
  error?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface PostFormData {
  title: string;
  content: string;
  excerpt?: string;
  featuredImage?: string;
  status: Post['status'];
  categoryId?: string;
  tags: string[];
  scheduledAt?: string;
  metaTitle?: string;
  metaDescription?: string;
  canonicalUrl?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
}

export interface CommentFormData {
  content: string;
  authorName?: string;
  authorEmail?: string;
  authorUrl?: string;
  parentId?: string;
}

